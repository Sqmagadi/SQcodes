<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLA NEW STUDENTS</title>
    <link rel="stylesheet" href="Crown_Lakes_Academy/cla_main/main.css">
</head>
<body>
   
    <?php
    include 'C:\xampp\htdocs\Crown_Lakes_Academy\cla_include\cla_navbar_all.php';
    include 'C:\xampp\htdocs\Crown_Lakes_Academy\cla_include\cla_header_all.php';
    ?>
    
    <h1>NEW STUDENTS</h1>
    

    
</body>
</html>